self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "url": "/1.269371ffc0005ab794af.css"
  },
  {
    "url": "/app.269371ffc0005ab794af.css"
  },
  {
    "revision": "4bbff1e06312f9e66ba8cac21ea56430",
    "url": "/images/404.svg"
  },
  {
    "revision": "d5b6139a919ec3440390831d973b89fb",
    "url": "/images/Bluebg.png"
  },
  {
    "revision": "bce4c69bc0e15b2957158547b02f842a",
    "url": "/images/Card.png"
  },
  {
    "revision": "eabf6e711e68cd5f3f5469a2b66b1677",
    "url": "/images/Check.png"
  },
  {
    "revision": "d41f53d0104a364d3adc6b85e530c971",
    "url": "/images/Contactbg.svg"
  },
  {
    "revision": "53e26c9291a3ce85fa6f316d7a9c7d6a",
    "url": "/images/Discover.png"
  },
  {
    "revision": "60394514b31ea2d0dee1da0e2a8a64b9",
    "url": "/images/Free.png"
  },
  {
    "revision": "8b94bb7858d98389b4b46bd136fb1091",
    "url": "/images/Setup.png"
  },
  {
    "revision": "87cea91eca1d1b4dafe0c3a4a43762aa",
    "url": "/images/Signup.png"
  },
  {
    "revision": "af6f5e8e6137411fcef61c5ad6be24ff",
    "url": "/images/SitarriWhiteLogo.svg"
  },
  {
    "revision": "83a6d7d1d776e3a8fe6a7398f4cf956d",
    "url": "/images/Speaker.png"
  },
  {
    "revision": "9922c0f69aeb8e9820a583f784453762",
    "url": "/images/amex.svg"
  },
  {
    "revision": "2edbf568491472c1f48ed97cd1abfacf",
    "url": "/images/arrow-back.svg"
  },
  {
    "revision": "6b6fbb409634c412398d80c53f3543a0",
    "url": "/images/arrow.svg"
  },
  {
    "revision": "c415e116740cdb1614b0f03c534772ad",
    "url": "/images/back.svg"
  },
  {
    "revision": "16b67a69b11e4adb99eede9a5e8eff46",
    "url": "/images/breadcrumbs-arrow.svg"
  },
  {
    "revision": "46e5dfb2cdad1754ee16cd521e551b7a",
    "url": "/images/carousel-arrow.svg"
  },
  {
    "revision": "2e279873fa0479e27bf8ff74f99eedd8",
    "url": "/images/cart.svg"
  },
  {
    "revision": "423a626c9c5659e6f50e9fc0fb8fff18",
    "url": "/images/discover.svg"
  },
  {
    "revision": "58459deddecb638da6f2605c015f5f91",
    "url": "/images/email.svg"
  },
  {
    "revision": "4d4a5fb539d20d261637816814ef806b",
    "url": "/images/facebook-icon.svg"
  },
  {
    "revision": "bc073e7f1f3042661cfbb1d992e13fa3",
    "url": "/images/facebook.svg"
  },
  {
    "revision": "3f42d6600133c9d11c68a1b703ee5ade",
    "url": "/images/favicons/android-chrome-144x144.png"
  },
  {
    "revision": "cf8708541d226cef36fa49458c202b60",
    "url": "/images/favicons/android-chrome-192x192.png"
  },
  {
    "revision": "e3704c0851741c4f7203b3decfe324c0",
    "url": "/images/favicons/android-chrome-256x256.png"
  },
  {
    "revision": "640006ce29e5e4f4435277fd1bcce0a7",
    "url": "/images/favicons/android-chrome-36x36.png"
  },
  {
    "revision": "3311647d6763e49a1d2f0ae804a5157d",
    "url": "/images/favicons/android-chrome-384x384.png"
  },
  {
    "revision": "c9b55b6dd090173d5f95bd3ce7417ab4",
    "url": "/images/favicons/android-chrome-48x48.png"
  },
  {
    "revision": "7bdb11e124e6a9526f6b0fcc62247024",
    "url": "/images/favicons/android-chrome-512x512.png"
  },
  {
    "revision": "5be83c90f4ca393fbe689a34d21da1e0",
    "url": "/images/favicons/android-chrome-72x72.png"
  },
  {
    "revision": "fd184ea5349e606990cc922ad6aa81d5",
    "url": "/images/favicons/android-chrome-96x96.png"
  },
  {
    "revision": "40af86f5cb1e3c065b16ba3a554adfc6",
    "url": "/images/favicons/apple-touch-icon-1024x1024.png"
  },
  {
    "revision": "770990c82a10dc5def64d11c7845f680",
    "url": "/images/favicons/apple-touch-icon-114x114.png"
  },
  {
    "revision": "e9716fad04ce357b051419925156ba0b",
    "url": "/images/favicons/apple-touch-icon-120x120.png"
  },
  {
    "revision": "521ea0f917fa637db47f8fcb5bc00695",
    "url": "/images/favicons/apple-touch-icon-144x144.png"
  },
  {
    "revision": "294188662f625e59e313104eb2f19dfb",
    "url": "/images/favicons/apple-touch-icon-152x152.png"
  },
  {
    "revision": "66ca7a2865eac4392ee5a83594a54fb1",
    "url": "/images/favicons/apple-touch-icon-167x167.png"
  },
  {
    "revision": "a7b23b9d7e4590dcf83cd563c7b339b3",
    "url": "/images/favicons/apple-touch-icon-180x180.png"
  },
  {
    "revision": "9e07bd71edd1882fe822945dd069ab26",
    "url": "/images/favicons/apple-touch-icon-57x57.png"
  },
  {
    "revision": "df171693d9a371846123e18260831bee",
    "url": "/images/favicons/apple-touch-icon-60x60.png"
  },
  {
    "revision": "e825f016245d5c903102d448b0b2db3f",
    "url": "/images/favicons/apple-touch-icon-72x72.png"
  },
  {
    "revision": "be1b4190378f15d0e9d7d177ede12d67",
    "url": "/images/favicons/apple-touch-icon-76x76.png"
  },
  {
    "revision": "a7b23b9d7e4590dcf83cd563c7b339b3",
    "url": "/images/favicons/apple-touch-icon-precomposed.png"
  },
  {
    "revision": "a7b23b9d7e4590dcf83cd563c7b339b3",
    "url": "/images/favicons/apple-touch-icon.png"
  },
  {
    "revision": "be35d5013278bc26f70acbae0dcdfae8",
    "url": "/images/favicons/apple-touch-startup-image-1182x2208.png"
  },
  {
    "revision": "1c97d12ff7c21518e8b9fe7e608f75de",
    "url": "/images/favicons/apple-touch-startup-image-1242x2148.png"
  },
  {
    "revision": "41b0ffd79e67dd179e2c317531c57594",
    "url": "/images/favicons/apple-touch-startup-image-1496x2048.png"
  },
  {
    "revision": "677f33d7022fa3cf9ec3647f7844c6c2",
    "url": "/images/favicons/apple-touch-startup-image-1536x2008.png"
  },
  {
    "revision": "e8246d406f983263f9f134ea86f422a3",
    "url": "/images/favicons/apple-touch-startup-image-320x460.png"
  },
  {
    "revision": "58c1206894cef0124760e026863a380b",
    "url": "/images/favicons/apple-touch-startup-image-640x1096.png"
  },
  {
    "revision": "75ef4e42557f37cc3bf06f4d4a0c49b5",
    "url": "/images/favicons/apple-touch-startup-image-640x920.png"
  },
  {
    "revision": "6f502c4c82fb3c45b10ce98fbf2570c5",
    "url": "/images/favicons/apple-touch-startup-image-748x1024.png"
  },
  {
    "revision": "e886aa50298e2ab455e406063c875304",
    "url": "/images/favicons/apple-touch-startup-image-750x1294.png"
  },
  {
    "revision": "b9eba5dabf359fb3c8482b2a58f9fa71",
    "url": "/images/favicons/apple-touch-startup-image-768x1004.png"
  },
  {
    "revision": "a4c4ae44d03d70fbddcb8a75c47dedd4",
    "url": "/images/favicons/browserconfig.xml"
  },
  {
    "revision": "6cce82dd15f4411a9ae793d8fe9a6c43",
    "url": "/images/favicons/coast-228x228.png"
  },
  {
    "revision": "240657170c366b16e788c888e9820b0b",
    "url": "/images/favicons/favicon-16x16.png"
  },
  {
    "revision": "ca21998d111788c8af2b746c6a6ae3f9",
    "url": "/images/favicons/favicon-32x32.png"
  },
  {
    "revision": "0c50c8015818eac19ec50766a8b3eea2",
    "url": "/images/favicons/favicon.ico"
  },
  {
    "revision": "dfa8576701849fc4847532710d1c8ca5",
    "url": "/images/favicons/firefox_app_128x128.png"
  },
  {
    "revision": "4600fa1640538af1d4e6fbbed2084687",
    "url": "/images/favicons/firefox_app_512x512.png"
  },
  {
    "revision": "1de785fdd0650525a1cc78223904a754",
    "url": "/images/favicons/firefox_app_60x60.png"
  },
  {
    "revision": "823f4a7124fe99d137ecab47233d3e00",
    "url": "/images/favicons/manifest.json"
  },
  {
    "revision": "d5c3bdad7f9e72fc7d74a0641bd2fba7",
    "url": "/images/favicons/manifest.webapp"
  },
  {
    "revision": "3f42d6600133c9d11c68a1b703ee5ade",
    "url": "/images/favicons/mstile-144x144.png"
  },
  {
    "revision": "60464daf654eb0bf10315cf2b6093384",
    "url": "/images/favicons/mstile-150x150.png"
  },
  {
    "revision": "1b33ed83d8216d6cc44b12bab3af46e3",
    "url": "/images/favicons/mstile-310x150.png"
  },
  {
    "revision": "bad391faf6b2af4aef4eb421454c9f8d",
    "url": "/images/favicons/mstile-310x310.png"
  },
  {
    "revision": "70bd97cd9c533ba9f909fe7fd21c4f5b",
    "url": "/images/favicons/mstile-70x70.png"
  },
  {
    "revision": "f76074f5347823a821e9ea4bbcc1d773",
    "url": "/images/favicons/yandex-browser-50x50.png"
  },
  {
    "revision": "abdc0a0e75a56d2b6e78d28ba374b217",
    "url": "/images/favicons/yandex-browser-manifest.json"
  },
  {
    "revision": "5e1cff6e63883c7f7cf4f5f031769834",
    "url": "/images/food.png"
  },
  {
    "revision": "72f0b80556965d101b99735a5382c1b5",
    "url": "/images/garbage.svg"
  },
  {
    "revision": "60ba99ba49ebcb48acf3455ee22ef22b",
    "url": "/images/hamburger-hover.svg"
  },
  {
    "revision": "5bacf6d70b4037a57f01cf8393e0b4d9",
    "url": "/images/hamburger.svg"
  },
  {
    "revision": "12b05d386c00b49580d8218c8df5a516",
    "url": "/images/iconmonstr-arrow-64.svg"
  },
  {
    "revision": "1c188d1e0fe5c753caec61536c64febe",
    "url": "/images/iconmonstr-arrow-72.svg"
  },
  {
    "revision": "0d3eacb6c4db48c19d3ea42404ba4ba6",
    "url": "/images/iconmonstr-crosshair-6.svg"
  },
  {
    "revision": "0bf6f4c0a3896678e57c3810c8f1c674",
    "url": "/images/iconmonstr-globe-5.svg"
  },
  {
    "revision": "f77513d1f352baf530982fe69a5ac2bb",
    "url": "/images/iconmonstr-location-1.svg"
  },
  {
    "revision": "c5c18cde84918c1c1029328da638a863",
    "url": "/images/iconmonstr-phone-1.svg"
  },
  {
    "revision": "8cece3edddf3f31ac88849a606a7e0b7",
    "url": "/images/iconmonstr-time-2.svg"
  },
  {
    "revision": "7b5a72acf998af55f544db47c5e92473",
    "url": "/images/instagram-icon.svg"
  },
  {
    "revision": "6a0b0bf08626df443a4143407f0aaa81",
    "url": "/images/instagram.svg"
  },
  {
    "revision": "35555a736d713af1d68af3f399b116f8",
    "url": "/images/jcb.svg"
  },
  {
    "revision": "f599835b64a7accb4490e280462786f0",
    "url": "/images/loader.svg"
  },
  {
    "revision": "23931e48215d17ef1a49e305307d84c8",
    "url": "/images/logo-small.svg"
  },
  {
    "revision": "c54be4acb8bfef9a5c2941d838e92f42",
    "url": "/images/logo.svg"
  },
  {
    "revision": "9d17cdd532fb79575cc394a6aa698008",
    "url": "/images/maestro.svg"
  },
  {
    "revision": "50b1bd2483c8925bd359272d376440a8",
    "url": "/images/mastercard.svg"
  },
  {
    "revision": "0d8a3af262b3ad471659bbb3898d2793",
    "url": "/images/modal-close.svg"
  },
  {
    "revision": "5fb648d744e29ed20689a767b5a0e4ea",
    "url": "/images/next.svg"
  },
  {
    "revision": "114a0c361476162e7ab92a80efcf4038",
    "url": "/images/no-photo.svg"
  },
  {
    "revision": "6d97b12a4cf1e40104056464c8cae9f2",
    "url": "/images/pass-invisible.svg"
  },
  {
    "revision": "7287f8410520b6c34822fc200fdf5495",
    "url": "/images/pass-visible.svg"
  },
  {
    "revision": "6b93bb60d647a066a38c8cdc3e82a5fb",
    "url": "/images/phone.png"
  },
  {
    "revision": "63e708bdd6e8630a929cb815c2fda5a8",
    "url": "/images/scooter.svg"
  },
  {
    "revision": "5d2e3191c838064534906a6b3a80a089",
    "url": "/images/search.svg"
  },
  {
    "revision": "ddf469f71d2dea460caac1791475f6af",
    "url": "/images/send.svg"
  },
  {
    "revision": "778050eca218c6a1d8361aa2ea844126",
    "url": "/images/share.svg"
  },
  {
    "revision": "f187a1d28910f7a09589492b1b4b35ca",
    "url": "/images/sittari.svg"
  },
  {
    "revision": "2cbed1f3f96e36f656d71fd4d20b4322",
    "url": "/images/subcategories.svg"
  },
  {
    "revision": "06f8273679c9414c0b0ff58569ec014b",
    "url": "/images/twitter.svg"
  },
  {
    "revision": "eb63482e3c6153359a36eb5abc604bde",
    "url": "/images/visa.svg"
  },
  {
    "revision": "ebc70e6743b684542437cef59a35c39f",
    "url": "/images/x.svg"
  },
  {
    "revision": "eba9402511d25eb16f526dcc29177ef6",
    "url": "/index.html"
  },
  {
    "revision": "37054e869dd0d3ca297d",
    "url": "/js/app.4e145b23922047ac05da.js"
  },
  {
    "revision": "cecaa4381492937efa9f",
    "url": "/js/vendors.c0b66c186f0379d1e005.js"
  }
]);