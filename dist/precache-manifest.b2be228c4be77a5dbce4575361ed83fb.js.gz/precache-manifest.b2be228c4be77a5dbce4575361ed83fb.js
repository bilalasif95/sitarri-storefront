self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "url": "/1.fbdd3b511e236215d7e4.css"
  },
  {
    "url": "/app.fbdd3b511e236215d7e4.css"
  },
  {
    "revision": "4bbff1e06312f9e66ba8cac21ea56430",
    "url": "/images/404.svg"
  },
  {
    "revision": "d5b6139a919ec3440390831d973b89fb",
    "url": "/images/Bluebg.png"
  },
  {
    "revision": "bce4c69bc0e15b2957158547b02f842a",
    "url": "/images/Card.png"
  },
  {
    "revision": "eabf6e711e68cd5f3f5469a2b66b1677",
    "url": "/images/Check.png"
  },
  {
    "revision": "d41f53d0104a364d3adc6b85e530c971",
    "url": "/images/Contactbg.svg"
  },
  {
    "revision": "53e26c9291a3ce85fa6f316d7a9c7d6a",
    "url": "/images/Discover.png"
  },
  {
    "revision": "60394514b31ea2d0dee1da0e2a8a64b9",
    "url": "/images/Free.png"
  },
  {
    "revision": "8b94bb7858d98389b4b46bd136fb1091",
    "url": "/images/Setup.png"
  },
  {
    "revision": "87cea91eca1d1b4dafe0c3a4a43762aa",
    "url": "/images/Signup.png"
  },
  {
    "revision": "af6f5e8e6137411fcef61c5ad6be24ff",
    "url": "/images/SitarriWhiteLogo.svg"
  },
  {
    "revision": "83a6d7d1d776e3a8fe6a7398f4cf956d",
    "url": "/images/Speaker.png"
  },
  {
    "revision": "9922c0f69aeb8e9820a583f784453762",
    "url": "/images/amex.svg"
  },
  {
    "revision": "2edbf568491472c1f48ed97cd1abfacf",
    "url": "/images/arrow-back.svg"
  },
  {
    "revision": "6b6fbb409634c412398d80c53f3543a0",
    "url": "/images/arrow.svg"
  },
  {
    "revision": "c415e116740cdb1614b0f03c534772ad",
    "url": "/images/back.svg"
  },
  {
    "revision": "16b67a69b11e4adb99eede9a5e8eff46",
    "url": "/images/breadcrumbs-arrow.svg"
  },
  {
    "revision": "46e5dfb2cdad1754ee16cd521e551b7a",
    "url": "/images/carousel-arrow.svg"
  },
  {
    "revision": "2e279873fa0479e27bf8ff74f99eedd8",
    "url": "/images/cart.svg"
  },
  {
    "revision": "423a626c9c5659e6f50e9fc0fb8fff18",
    "url": "/images/discover.svg"
  },
  {
    "revision": "58459deddecb638da6f2605c015f5f91",
    "url": "/images/email.svg"
  },
  {
    "revision": "4d4a5fb539d20d261637816814ef806b",
    "url": "/images/facebook-icon.svg"
  },
  {
    "revision": "bc073e7f1f3042661cfbb1d992e13fa3",
    "url": "/images/facebook.svg"
  },
  {
    "revision": "c5cbf34061a9603c78f91834cca6810e",
    "url": "/images/favicons/android-chrome-144x144.png"
  },
  {
    "revision": "c0dc5788687b23d88d4103d9ace6d44d",
    "url": "/images/favicons/android-chrome-192x192.png"
  },
  {
    "revision": "6dcb48bae5cb3f35663cc4106bde7d37",
    "url": "/images/favicons/android-chrome-256x256.png"
  },
  {
    "revision": "c4b922fee4f4bfeb06c4420cfe9aef40",
    "url": "/images/favicons/android-chrome-36x36.png"
  },
  {
    "revision": "3a9b7a0e49ef16e5e7d807a5152ba9d9",
    "url": "/images/favicons/android-chrome-384x384.png"
  },
  {
    "revision": "a13fc55e7978c8de298b6c6d267c97e5",
    "url": "/images/favicons/android-chrome-48x48.png"
  },
  {
    "revision": "d3f8221ee206b3007c20f75ce4ec2cc8",
    "url": "/images/favicons/android-chrome-512x512.png"
  },
  {
    "revision": "6cb1a45e9771b17bd36dd69996211f84",
    "url": "/images/favicons/android-chrome-72x72.png"
  },
  {
    "revision": "2e00ffa46767b885ea9a9e25c0edf32b",
    "url": "/images/favicons/android-chrome-96x96.png"
  },
  {
    "revision": "9a94ff9f1d16568386264190b22ac72f",
    "url": "/images/favicons/apple-touch-icon-1024x1024.png"
  },
  {
    "revision": "20f8ecd495e477ea93bcea6803a197b8",
    "url": "/images/favicons/apple-touch-icon-114x114.png"
  },
  {
    "revision": "9ffa5906761ef4e643436613094d8b55",
    "url": "/images/favicons/apple-touch-icon-120x120.png"
  },
  {
    "revision": "245314bb4daae2e217ecbabe747cab4e",
    "url": "/images/favicons/apple-touch-icon-144x144.png"
  },
  {
    "revision": "a46790ed10b18c7dbbd1b72891ecac4d",
    "url": "/images/favicons/apple-touch-icon-152x152.png"
  },
  {
    "revision": "4cf474a9f98daad1b0302d40c22600f6",
    "url": "/images/favicons/apple-touch-icon-167x167.png"
  },
  {
    "revision": "df84f037d76091e533a80574b155c990",
    "url": "/images/favicons/apple-touch-icon-180x180.png"
  },
  {
    "revision": "c531b998558375e06f55aab16b623a29",
    "url": "/images/favicons/apple-touch-icon-57x57.png"
  },
  {
    "revision": "09370a70e0334f573c05e7bbb74e351f",
    "url": "/images/favicons/apple-touch-icon-60x60.png"
  },
  {
    "revision": "55e2145a103e7e888acf8f9f3b0ca270",
    "url": "/images/favicons/apple-touch-icon-72x72.png"
  },
  {
    "revision": "b2f4a96bd411041ec3d95bb303d935b3",
    "url": "/images/favicons/apple-touch-icon-76x76.png"
  },
  {
    "revision": "df84f037d76091e533a80574b155c990",
    "url": "/images/favicons/apple-touch-icon-precomposed.png"
  },
  {
    "revision": "df84f037d76091e533a80574b155c990",
    "url": "/images/favicons/apple-touch-icon.png"
  },
  {
    "revision": "a5bce3926257dd63f3f4704af2f9a291",
    "url": "/images/favicons/apple-touch-startup-image-1182x2208.png"
  },
  {
    "revision": "6f721bb2cead99a8dc13ed5750c16274",
    "url": "/images/favicons/apple-touch-startup-image-1242x2148.png"
  },
  {
    "revision": "da0fb807cc72202c921db0dc2a2c04c4",
    "url": "/images/favicons/apple-touch-startup-image-1496x2048.png"
  },
  {
    "revision": "0e01f396d05a7cbf18b90b446f585970",
    "url": "/images/favicons/apple-touch-startup-image-1536x2008.png"
  },
  {
    "revision": "4c19c191f3008ee28682b0fb9b3161b3",
    "url": "/images/favicons/apple-touch-startup-image-320x460.png"
  },
  {
    "revision": "86bb044214ed53c5683c1e3beb71a710",
    "url": "/images/favicons/apple-touch-startup-image-640x1096.png"
  },
  {
    "revision": "7bf4f29c5b6fe828e10449d54490958b",
    "url": "/images/favicons/apple-touch-startup-image-640x920.png"
  },
  {
    "revision": "07915f0f2a5de2c01afddb96967f9456",
    "url": "/images/favicons/apple-touch-startup-image-748x1024.png"
  },
  {
    "revision": "eccb2e8ab17ab52fd5e782f8621607e8",
    "url": "/images/favicons/apple-touch-startup-image-750x1294.png"
  },
  {
    "revision": "b17eb7278713a7ecda5845695e49d159",
    "url": "/images/favicons/apple-touch-startup-image-768x1004.png"
  },
  {
    "revision": "a4c4ae44d03d70fbddcb8a75c47dedd4",
    "url": "/images/favicons/browserconfig.xml"
  },
  {
    "revision": "8ad077d097356fda5dfaecc4fc4bd66b",
    "url": "/images/favicons/coast-228x228.png"
  },
  {
    "revision": "c0af549abbe9478c9e100070486242a1",
    "url": "/images/favicons/favicon-16x16.png"
  },
  {
    "revision": "40e2d9b6cd247a2740d60cb51ef7035a",
    "url": "/images/favicons/favicon-32x32.png"
  },
  {
    "revision": "58af25d432c15d81ccc4f7fe9007f702",
    "url": "/images/favicons/favicon.ico"
  },
  {
    "revision": "a0f116d6a2c32e30bca19c6591f232c5",
    "url": "/images/favicons/firefox_app_128x128.png"
  },
  {
    "revision": "0278c972ea3fc43b261e5bd376b63bef",
    "url": "/images/favicons/firefox_app_512x512.png"
  },
  {
    "revision": "fb367e7bd9483642004549c7456206ec",
    "url": "/images/favicons/firefox_app_60x60.png"
  },
  {
    "revision": "823f4a7124fe99d137ecab47233d3e00",
    "url": "/images/favicons/manifest.json"
  },
  {
    "revision": "d5c3bdad7f9e72fc7d74a0641bd2fba7",
    "url": "/images/favicons/manifest.webapp"
  },
  {
    "revision": "c5cbf34061a9603c78f91834cca6810e",
    "url": "/images/favicons/mstile-144x144.png"
  },
  {
    "revision": "79bef629259558398fa84a3f1a65a2a7",
    "url": "/images/favicons/mstile-150x150.png"
  },
  {
    "revision": "5f95d4c0d70c1ce4cf51dc9db12f9264",
    "url": "/images/favicons/mstile-310x150.png"
  },
  {
    "revision": "9522e6121f35bdc7084a6e9bedac14a2",
    "url": "/images/favicons/mstile-310x310.png"
  },
  {
    "revision": "f32fefddd1abfa4966258817362df8a9",
    "url": "/images/favicons/mstile-70x70.png"
  },
  {
    "revision": "1161be4cfd7b909f58ab08b1577b7108",
    "url": "/images/favicons/yandex-browser-50x50.png"
  },
  {
    "revision": "abdc0a0e75a56d2b6e78d28ba374b217",
    "url": "/images/favicons/yandex-browser-manifest.json"
  },
  {
    "revision": "5e1cff6e63883c7f7cf4f5f031769834",
    "url": "/images/food.png"
  },
  {
    "revision": "72f0b80556965d101b99735a5382c1b5",
    "url": "/images/garbage.svg"
  },
  {
    "revision": "60ba99ba49ebcb48acf3455ee22ef22b",
    "url": "/images/hamburger-hover.svg"
  },
  {
    "revision": "5bacf6d70b4037a57f01cf8393e0b4d9",
    "url": "/images/hamburger.svg"
  },
  {
    "revision": "12b05d386c00b49580d8218c8df5a516",
    "url": "/images/iconmonstr-arrow-64.svg"
  },
  {
    "revision": "1c188d1e0fe5c753caec61536c64febe",
    "url": "/images/iconmonstr-arrow-72.svg"
  },
  {
    "revision": "0d3eacb6c4db48c19d3ea42404ba4ba6",
    "url": "/images/iconmonstr-crosshair-6.svg"
  },
  {
    "revision": "0bf6f4c0a3896678e57c3810c8f1c674",
    "url": "/images/iconmonstr-globe-5.svg"
  },
  {
    "revision": "f77513d1f352baf530982fe69a5ac2bb",
    "url": "/images/iconmonstr-location-1.svg"
  },
  {
    "revision": "c5c18cde84918c1c1029328da638a863",
    "url": "/images/iconmonstr-phone-1.svg"
  },
  {
    "revision": "8cece3edddf3f31ac88849a606a7e0b7",
    "url": "/images/iconmonstr-time-2.svg"
  },
  {
    "revision": "7b5a72acf998af55f544db47c5e92473",
    "url": "/images/instagram-icon.svg"
  },
  {
    "revision": "6a0b0bf08626df443a4143407f0aaa81",
    "url": "/images/instagram.svg"
  },
  {
    "revision": "35555a736d713af1d68af3f399b116f8",
    "url": "/images/jcb.svg"
  },
  {
    "revision": "f599835b64a7accb4490e280462786f0",
    "url": "/images/loader.svg"
  },
  {
    "revision": "23931e48215d17ef1a49e305307d84c8",
    "url": "/images/logo-small.svg"
  },
  {
    "revision": "c54be4acb8bfef9a5c2941d838e92f42",
    "url": "/images/logo.svg"
  },
  {
    "revision": "9d17cdd532fb79575cc394a6aa698008",
    "url": "/images/maestro.svg"
  },
  {
    "revision": "50b1bd2483c8925bd359272d376440a8",
    "url": "/images/mastercard.svg"
  },
  {
    "revision": "0d8a3af262b3ad471659bbb3898d2793",
    "url": "/images/modal-close.svg"
  },
  {
    "revision": "5fb648d744e29ed20689a767b5a0e4ea",
    "url": "/images/next.svg"
  },
  {
    "revision": "114a0c361476162e7ab92a80efcf4038",
    "url": "/images/no-photo.svg"
  },
  {
    "revision": "6d97b12a4cf1e40104056464c8cae9f2",
    "url": "/images/pass-invisible.svg"
  },
  {
    "revision": "7287f8410520b6c34822fc200fdf5495",
    "url": "/images/pass-visible.svg"
  },
  {
    "revision": "6b93bb60d647a066a38c8cdc3e82a5fb",
    "url": "/images/phone.png"
  },
  {
    "revision": "63e708bdd6e8630a929cb815c2fda5a8",
    "url": "/images/scooter.svg"
  },
  {
    "revision": "5d2e3191c838064534906a6b3a80a089",
    "url": "/images/search.svg"
  },
  {
    "revision": "ddf469f71d2dea460caac1791475f6af",
    "url": "/images/send.svg"
  },
  {
    "revision": "778050eca218c6a1d8361aa2ea844126",
    "url": "/images/share.svg"
  },
  {
    "revision": "f187a1d28910f7a09589492b1b4b35ca",
    "url": "/images/sittari.svg"
  },
  {
    "revision": "2cbed1f3f96e36f656d71fd4d20b4322",
    "url": "/images/subcategories.svg"
  },
  {
    "revision": "06f8273679c9414c0b0ff58569ec014b",
    "url": "/images/twitter.svg"
  },
  {
    "revision": "eb63482e3c6153359a36eb5abc604bde",
    "url": "/images/visa.svg"
  },
  {
    "revision": "ebc70e6743b684542437cef59a35c39f",
    "url": "/images/x.svg"
  },
  {
    "revision": "58449385e7ac801f3d91a4be460fb363",
    "url": "/index.html"
  },
  {
    "revision": "c26121832107a5d45031",
    "url": "/js/app.34c01216d15a187df33f.js"
  },
  {
    "revision": "d5a2ec345309416d6570",
    "url": "/js/vendors.67bd5d1d39fbb84a4980.js"
  }
]);